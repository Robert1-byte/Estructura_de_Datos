/***********************************************************************
 * Module:  ValidarDia.h
 * Author:  USUARIO
 * Modified: domingo, 27 de abril de 2025 11:56:42
 * Purpose: Declaration of the class ValidarDia
 ***********************************************************************/

#if !defined(__Fecha2_ValidarDia_h)
#define __Fecha2_ValidarDia_h

class ValidarDia
{
public:
   bool validarDia(int dia, int mes, int anio);

protected:
private:

};

#endif